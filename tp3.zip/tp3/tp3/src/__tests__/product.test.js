const { ObetenirProduitStock} = require("../products");
const { ObtenirRecommendationProduit } = require("../products");

/** 
* @function  ObetenirProduitStock

* @param  {Array}  products - Liste des produits
* @returns  {Object} Informations sur le stock des produits par catégorie
*/
function ObetenirProduitStock
(products) {
    const InfoStock = {};
    products.forEach(product => {
      if (!InfoStock[product.category]) {
        InfoStock[product.category] = [];
      }
      let EtatStock;
      if (product.stock < 10) {
        EtatStock = "faible";
      } else if (product.stock >= 10 && product.stock <= 50) {
        EtatStock = "moyen";
      } else {
        EtatStock = "grand";
      }
      InfoStock[product.category].push({ libelle: product.label, dispo: EtatStock });
    });
    return InfoStock;
  }

/**
 * @function ObtenirRecommendationProduit
 * @param {string} userId - ID de l'utilisateur
 * @param {number} age - Âge de l'utilisateur
 * @param {Array} products - Liste des produits
 * @param {Date} birthday - Date d'anniversaire de l'utilisateur
 * @returns {Array|string} Recommandations de produits ou adresse mail si c'est l'anniversaire de l'utilisateur
 * @throws {Error} Erreur si l'utilisateur est mineur
 */
function ObtenirRecommendationProduit(userId, age, products, birthday) {
  if (age >= 0 && age < 18) {
    throw new Error("Le site n'est pas ouvert aux mineurs.");
  } else if (age >= 18 && age <= 25) {
    // Retourner les 10 produits avec la plus grande économie
    const sortedProducts = products
      .filter(product => product.price - product.discountedPrice > 0)
      .sort((a, b) => (b.price - b.discountedPrice) - (a.price - a.discountedPrice));
    return sortedProducts.slice(0, 10);
  } else if (age >= 26 && age <= 50) {
    // Retourner les produits avec une note supérieure à 4.7
    return products.filter(product => product.rating > 4.7);
  } else if (age > 50) {
    // Retourner les produits de la catégorie "smartphone"
    return products.filter(product => product.category === "smartphone");
  } else {
    return "Âge invalide";
  }
  
  // Vérifier si c'est l'anniversaire de l'utilisateur
  const today = new Date();
  if (birthday.getDate() === today.getDate() && birthday.getMonth() === today.getMonth()) {
    return userId; // Retourner l'adresse mail de l'utilisateur si c'est son anniversaire
  }
}

  module.exports = {
    ObetenirProduitStock,
    ObtenirRecommendationProduit

  };
  