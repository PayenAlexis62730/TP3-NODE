const {  ObtenirNuméroTel50ans } = require("../users");
const { ObtenirClientAcheteur, ObtenirPanierUtilisateur } = require("../users");

/** 
* @function  ObtenirNuméroTel50ans
* @param  {Array}  users - Liste des utilisateurs
* @returns  {Array} Liste des numéros de téléphone des utilisateurs de plus de 50 ans
*/
function ObtenirNuméroTel50ans(users) {
    return users
      .filter(user => user.age > 50 && user.phoneNumber)
      .map(user => user.phoneNumber);
  }

/** 
* @function  ObtenirClientAcheteur
* @param  {string}  productId - ID du produit
* @param  {Array}  userCarts - Liste des paniers des utilisateurs
* @returns  {Array|string} Liste des IDs des utilisateurs ayant acheté le produit ou un message indiquant que le produit n'est présent dans aucun panier
*/
function ObtenirClientAcheteur(productId, userCarts) {
  const users = userCarts.reduce((acc, userCart) => {
    const cart = userCart.cart || [];
    const user = userCart.userId || 'unknown';
    if (cart.some(item => item.productId === productId)) {
      acc.push(user);
    }
    return acc;
  }, []);

  return users.length > 0 ? users : "Ce produit n'est présent dans aucun panier";
}

/** 
* @function  ObtenirPanierUtilisateur
* @param  {string}  userId - ID de l'utilisateur
* @param  {Array}  userCarts - Liste des paniers des utilisateurs
* @returns  {Object|string} Objet contenant le prix total et le prix total "discount" du panier de l'utilisateur ou son adresse mail, ou son adresse mail si le prix total dépasse 1000€
*/
function ObtenirPanierUtilisateur(userId, userCarts) {
  const userCart = userCarts.find(cart => cart.userId === userId);
  if (!userCart) {
    return userId; // Utilisateur sans panier on retourne son adresse mail
  }

  const totalPrice = userCart.cart.reduce((acc, item) => acc + item.total, 0);
  const totalDiscountedPrice = userCart.cart.reduce((acc, item) => acc + item.totalDiscounted, 0);

  if (totalPrice > 1000) {
    return userId; // Si le prix total dépasse 1000€ on retourne son adresse mail
  }

  return { totalPrice, totalDiscountedPrice };
}

module.exports = {
  ObtenirNuméroTel50ans,
  ObtenirClientAcheteur,
  ObtenirPanierUtilisateur,

};
