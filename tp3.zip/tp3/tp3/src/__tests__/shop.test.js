const { getUser } = require("../shop");
const fakeUsers = require("../__mocks__/fakeUserValid.json");

/** 
* @function  getUser
* @param  {number}  id
* @param  {Array}  users
* @returns  {Object} L'utilisateur correspondant à l'identifiant donné
* @throws {Error} Si l'utilisateur n'existe pas, si l'identifiant est du mauvais type, si la liste des utilisateurs est du mauvais type, si la liste des utilisateurs est vide, ou si l'identifiant est invalide
*/
function getUser(id, users) {
  if (typeof id !== 'number' || id <= 0 || !Number.isInteger(id)) {
    throw new Error("L'identifiant doit être un entier positif");
  }
  if (!Array.isArray(users)) {
    throw new Error("La liste des utilisateurs doit être un tableau contenant des utilisateurs");
  }
  if (users.length === 0) {
    throw new Error("La liste des utilisateurs est vide");
  }
  const user = users.find(user => user.id === id);
  if (!user) {
    throw new Error(`L'utilisateur ${id} n'existe pas!`);
  }
  return user;
}

module.exports = {
  getUser
};
