const { addition, quotient } = require("../maths");

/** 
* @function  addition
* @param  {number}  a
* @param  {number}  b
* @returns  {number} Somme de a et de b
*/
function addition(a, b) {
  if (typeof a !== 'number' || typeof b !== 'number') {
    throw new Error("Mauvais type!");
  }
  return a + b;
}

/** 
* @function  quotient
* @param  {number}  a
* @param  {number}  b
* @returns  {number} Quotient de a par b
*/
function quotient(a, b) {
  if (typeof a !== 'number' || typeof b !== 'number') {
    throw new Error("Mauvais type!");
  }
  if (b === 0) {
    throw new Error("Division par zéro!");
  }
  return a / b;
}

module.exports = {
  addition,
  quotient
};

